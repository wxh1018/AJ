搭建QQ机器人:
1 去酷Q官网下载   酷Q Air 图灵版
https://cqp.cc/t/23253
2 下载后应该是 CQA-tuling.zip
3 解压后打开  CQA.exe
4 登录qq号
5 右击酷Q图标  选择应用  应用管理  获取更多应用
6 推荐主题中可以看到   语言库 - 简易应答，轻松添加
7 下载   moe.min.qa.cpk (376.22 KB, 下载次数: 53102)
8 放到  E:\qq机器人\CQA-tuling\酷Q Air\app
      (不一定目录要一样,只要放到app文件夹里就行)
9 重启酷Q
10 根据 5 打开应用管理页面, 点击语言库, 点击启用, 点击菜单,点击语言库管理
11 添加机器人关键词即可
12  主要是添加  关键词 和  回答
如果有群成员发送了<关键词>   机器人就会发送<回答>


#pro官网$
https://pro.autojs.org/
#(淘宝|购买)$
https://shop218793855.taobao.com/index.htm
#论坛$
https://www.autojs.org/
#(git|github)$
https://github.com/hyb1996/Auto.js
#文档$
https://hyb1996.github.io/AutoJs-Docs/#/
#(应用|app)$
https://hyb1996.github.io/AutoJs-Docs/#/app
#(一般全局函数|globals)$
https://hyb1996.github.io/AutoJs-Docs/#/globals
#(控制台|console)$
https://hyb1996.github.io/AutoJs-Docs/#/console
#(坐标)$
https://hyb1996.github.io/AutoJs-Docs/#/coordinatesBasedAutomation
#(设备|device)$
https://hyb1996.github.io/AutoJs-Docs/#/device
#(对话框|dialogs)$
https://hyb1996.github.io/AutoJs-Docs/#/dialogs
#(脚本引擎|engines)$
https://hyb1996.github.io/AutoJs-Docs/#/engines
#(事件与监听|events)$
https://hyb1996.github.io/AutoJs-Docs/#/events
#(悬浮窗|floaty)$
https://hyb1996.github.io/AutoJs-Docs/#/floaty
#(文件系统|files)$
https://hyb1996.github.io/AutoJs-Docs/#/files
#(http)$
https://hyb1996.github.io/AutoJs-Docs/#/http
#(图片与颜色|images|图色)$
https://hyb1996.github.io/AutoJs-Docs/#/images
#(画布|canvas)$
https://hyb1996.github.io/AutoJs-Docs/#/canvas
#(按键模拟|keys)$
https://hyb1996.github.io/AutoJs-Docs/#/keys
#(多媒体|media)$
https://hyb1996.github.io/AutoJs-Docs/#/media
#(模块|modules)$
https://hyb1996.github.io/AutoJs-Docs/#/modules
#(控件)$
https://hyb1996.github.io/AutoJs-Docs/#/widgetsBasedAutomation
#(传感器|sensor)$
https://hyb1996.github.io/AutoJs-Docs/#/sensors
#(shell)$
https://hyb1996.github.io/AutoJs-Docs/#/shell
#(本地储存|storages)$
https://hyb1996.github.io/AutoJs-Docs/#/storages
#(多线程|threads)$
https://hyb1996.github.io/AutoJs-Docs/#/threads
#(定时器|timers)$
https://hyb1996.github.io/AutoJs-Docs/#/timers
#(用户界面|ui)$
https://hyb1996.github.io/AutoJs-Docs/#/ui
#(demo)$
https://github.com/snailuncle/autojsDemo
#(ck|cookie)$
https://github.com/snailuncle/autojsDemo/blob/master/%E5%B7%A5%E5%85%B7%E7%AE%B1/cookie.js
#(加密)$
https://github.com/snailuncle/autojsDemo/tree/master/%E5%8A%A0%E5%AF%86
#(通信|脚本通信)$
https://github.com/snailuncle/autojsDemo/tree/master/%E5%B7%A5%E5%85%B7%E7%AE%B1/%E8%84%9A%E6%9C%AC%E9%80%9A%E4%BF%A1
#(排队|脚本排队|脚本队列)$
https://github.com/snailuncle/autojsDemo/blob/master/%E5%B7%A5%E5%85%B7%E7%AE%B1/%E8%84%9A%E6%9C%AC%E6%8E%92%E9%98%9F%E6%A8%A1%E5%9D%97155.js
#(intent)$
https://github.com/snailuncle/autojsDemo/tree/master/intent
#(http超时)$
https://github.com/snailuncle/autojsDemo/blob/master/http/http%E8%B6%85%E6%97%B6%E8%BF%94%E5%9B%9Enull.js
#(无障碍)$
https://github.com/snailuncle/autojsDemo/blob/master/UI/ui%E8%84%9A%E6%9C%AC%E4%BD%BF%E7%94%A8%E6%97%A0%E9%9A%9C%E7%A2%8D%E7%9A%84%E6%9C%80%E4%BD%B3%E5%AE%9E%E8%B7%B5.js
#(spinner)$
https://github.com/snailuncle/autojsDemo/blob/master/UI/spinner.js
#(动态布局)$
https://github.com/snailuncle/autojsDemo/blob/master/UI/%E5%8A%A8%E6%80%81%E5%B8%83%E5%B1%80.js
