"ui";
ui.layout(
    <vertical>
    <text id="test"/>
    <horizontal>
    <button id="Q" text="Q" w="35"/>
    <button id="W" text="W" w="38"/>
    <button id="E" text="E" w="35"/>
    <button id="R" text="R" w="35"/>
    <button id="T" text="T" w="35"/>
    <button id="Y" text="Y" w="35"/>
    <button id="U" text="U" w="35"/>
    <button id="I" text="I" w="35"/>
    <button id="O" text="O" w="35"/>
    <button id="P" text="P" w="35"/>
    </horizontal>
        <horizontal>
        <text w="20"/>
    <button id="A" text="A" w="35"/>
    <button id="S" text="S" w="35"/>
    <button id="D" text="D" w="35"/>
    <button id="F" text="F" w="35"/>
    <button id="G" text="G" w="35"/>
    <button id="H" text="H" w="35"/>
    <button id="J" text="J" w="35"/>
    <button id="K" text="K" w="35"/>
    <button id="L" text="L" w="35"/>
    <text w="20"/>
    </horizontal>
        <horizontal>
        <button id="nn" w="55" text="行"/>
    <button id="Z" text="Z" w="35"/>
    <button id="X" text="X" w="35"/>
    <button id="C" text="C" w="35"/>
    <button id="V" text="V" w="35"/>
    <button id="B" text="B" w="35"/>
    <button id="N" text="N" w="35"/>
    <button id="M" text="M" w="35"/>
    <button id="删" text="删" w="55"/>
    </horizontal>
    <button id="空" text="空格"/>
    <button id="yes" text="yes"/>
    <text>注:删=删除全部
    由于我太lj，所以做不出来，如果有大神知道可以自己改。</text>
    </vertical>
)
ui.A.click(function(){
    var text = ui.test.getText()
    ui.test.setText(text+"A")
    });
ui.B.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"B")
});
ui.C.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"C")
});
ui.D.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"D")
});
ui.E.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"E")
});
ui.F.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"F")
});
ui.G.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"G")
});
ui.H.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"H")
});
ui.I.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"I")
});
ui.J.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"J")
});
ui.K.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"K")
});
ui.L.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"L")
});
ui.M.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"M")
});
ui.N.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"N")
});
ui.O.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"O")
});
ui.P.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"P")
});
ui.Q.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"Q")
});
ui.R.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"R")
});
ui.S.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"S")
});
ui.T.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"T")
});
ui.U.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"U")
});
ui.V.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"V")
});
ui.W.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"W")
});
ui.X.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"X")
});
ui.Y.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"Y")
});
ui.Z.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"Z")
});
ui.空.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+" ")
});
ui.删.click(function(){
var text = ui.test.getText()
    ui.test.setText("")
});
ui.nn.click(function(){
var text = ui.test.getText()
    ui.test.setText(text+"\n")
});