let n = 1024 * 1024;
let arr = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, n);
java.util.Arrays.fill(arr, 50);
