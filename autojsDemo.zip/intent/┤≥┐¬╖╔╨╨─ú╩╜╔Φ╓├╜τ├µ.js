var intent=new Intent()
intent.setAction("android.settings.AIRPLANE_MODE_SETTINGS")
app.startActivity(intent)
