app.startActivity({
  action: "android.intent.action.VIEW",
  data: "taobao://hitow.net"
});