var intent=new Intent()
intent.setAction("android.settings.VPN_SETTINGS")
app.startActivity(intent)
