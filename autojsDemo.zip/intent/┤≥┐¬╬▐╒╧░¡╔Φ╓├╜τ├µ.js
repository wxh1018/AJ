var intent = new Intent();
intent.setAction("android.settings.ACCESSIBILITY_SETTINGS"); //打开无障碍设置界面
app.startActivity(intent);
