app.startActivity({
  packageName : "org.autojs.autojs",
  className : "org.autojs.autojs.external.open.RunIntentActivity",
  data : "/sdcard/脚本/2.js",
  type : "application/x-javascript"
});
