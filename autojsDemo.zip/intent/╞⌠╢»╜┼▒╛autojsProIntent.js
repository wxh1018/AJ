app.startActivity({
  packageName : "org.autojs.autojspro",
  className : "org.autojs.autojs.external.open.RunIntentActivity",
  data : "/sdcard/脚本/2.js",
  type : "application/x-javascript"
});
