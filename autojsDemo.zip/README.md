# 一些autojs的脚本
# autojs作者已经决定不再维护autojs, 2019.9.3日最后一次收集整理qq群脚本, 感谢各位qq群员的分享, 此仓库不再更新.
# autojs作者新的安卓端软件, pluto.js V8, 不包含无障碍, 使用 V8 引擎, 支持nodejs, 目标是玩具,工具,应用开发.
# pluto交流q群 662377009   
<div align=center>
<img width="300" height="300" src="https://raw.githubusercontent.com/snailuncle/autojsDemo/master/111111111%E6%9F%B4%E6%88%BF/yeah.png"/>
<img width="300" height="300" src="https://raw.githubusercontent.com/snailuncle/autojsDemo/master/111111111%E6%9F%B4%E6%88%BF/%E5%BE%AE%E4%BF%A1%E8%B5%9E%E8%B5%8F%E7%A0%81.png"/>
<img width="300" height="467" src="https://raw.githubusercontent.com/snailuncle/autojsDemo/master/111111111%E6%9F%B4%E6%88%BF/%E6%94%AF%E4%BB%98%E5%AE%9D%E6%94%B6%E6%AC%BE%E7%A0%81.jpg"/>
</div>