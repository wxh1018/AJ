"ui";
var ui的引用=require('./ui模块.js')
log(ui的引用.text())
