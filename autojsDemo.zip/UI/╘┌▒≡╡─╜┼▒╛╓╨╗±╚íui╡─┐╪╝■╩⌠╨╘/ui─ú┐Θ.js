"ui";
ui.layout(
  <vertical>
    <button id="myButton" text="this is a button"></button>
  </vertical>
)
module.exports=ui.myButton
