'ui';
ui.layout(
  <horizontal weightSum="8" bg='#888888'>
    <button  layout_width="0dp" layout_weight="3" ></button>
    <button  layout_width="0dp" layout_weight="1" ></button>
    <button  layout_width="0dp" layout_weight="1" ></button>
    <button  layout_width="0dp" layout_weight="3" ></button>
  </horizontal>
)

