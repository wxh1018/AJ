var w = floaty.rawWindow(
    <frame>
    <img w="640" scaleType="fitStart" src="http://f2.dn.anqu.com/down/MDdhOQ==/allimg/1308/54-130P6111G3.jpg" alpha="0.3"/>
   </frame>
);

w.setTouchable(false);

setTimeout(()=>{
    w.close();
}, 360000);
//720*1280分辨率显示正常