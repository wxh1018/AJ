"ui";
ui.layout(
<frame>
<relative
    layout_width="match_parent"
    layout_height="match_parent" >

   <frame
       layout_width="120pt"
       layout_height="120pt"
       background="#00ff00">
       <frame
           layout_width="100pt"
           layout_height="100pt"
           background="#00f0f0">
       </frame>

       <frame
           layout_width="80pt"
           layout_height="80pt"
           background="#0000ff">
       </frame>

       <frame
           layout_width="60pt"
           layout_height="60pt"
           background="#00ffff">
       </frame>

       <frame
           layout_width="40pt"
           layout_height="40pt"
           background="#000000">
       </frame>

   </frame>

</relative>
</frame>

);
